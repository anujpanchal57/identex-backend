default_bteam_name = "All Users"

default_bteam_id = "All_Users"